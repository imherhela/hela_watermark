config = {
    framework = 'vorp', -- Change this to 'rsg' or 'redemrp' as needed    
    allowoff = true, -- Should the player be able to turn off the watermark?
    position = 'top-right' -- Default position for the watermark. Other position options ('bottom-left', 'top-left', 'top-center')
}
